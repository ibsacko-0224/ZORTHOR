// Test de fumée : la boucle principale de bout en bout, via les VRAIS gestionnaires de routes
// (créer un site → modifier une section → aperçu → publier → zip → export → import → suppression).
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { after, before, test } from 'node:test';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'hexsite-e2e-'));
process.env.DATA_DIR = path.join(tmp, 'data');
process.env.PUBLISH_DIR = path.join(tmp, 'exports');
delete process.env.ANTHROPIC_API_KEY;   // mode sans IA

const post = (url: string, body?: unknown) => new Request(`http://localhost${url}`, { method: 'POST', body: body === undefined ? undefined : JSON.stringify(body) });
const ctx = (id: string) => ({ params: Promise.resolve({ id }) });

let R: Record<string, any>;
before(async () => {
  R = {
    health: await import('../src/app/api/health/route'),
    list: await import('../src/app/api/projects/route'),
    one: await import('../src/app/api/projects/[id]/route'),
    rewrite: await import('../src/app/api/projects/[id]/rewrite/route'),
    publish: await import('../src/app/api/projects/[id]/publish/route'),
    zip: await import('../src/app/api/projects/[id]/zip/route'),
    exp: await import('../src/app/api/projects/[id]/export/route'),
    imp: await import('../src/app/api/projects/import/route'),
    samples: await import('../src/app/api/samples/route'),
  };
});
after(() => fs.rmSync(tmp, { recursive: true, force: true }));

test('boucle principale complète, sans clé IA', async () => {
  // état initial : vide, IA non configurée
  assert.deepEqual(await (await R.health.GET()).json(), { ok: true, ai: { configured: false } });
  assert.deepEqual(await (await R.list.GET()).json(), []);

  // validation : un brief vide est refusé avec des messages exploitables
  const bad = await R.list.POST(post('/api/projects', { brief: { name: '', description: '' } }));
  assert.equal(bad.status, 400);
  assert.ok((await bad.json()).error.issues.some((i: string) => i.includes('brief.name')));

  // 1. création depuis un brief → mode sans IA, indiqué
  const res = await R.list.POST(post('/api/projects', { brief: { name: 'Studio Lumen', description: 'Photographe de portraits. Séances en studio. Retouches incluses.', audience: 'Particuliers', tone: 'chaleureux', language: 'fr', contactEmail: 'hello@lumen.test' } }));
  assert.equal(res.status, 201);
  const created = await res.json();
  assert.equal(created.mode, 'degraded');
  assert.match(created.note, /sans IA/);
  const id: string = created.project.id;

  // 2. modification d'une section (comme dans l'éditeur)
  const p = created.project;
  const sections = p.sections.map((s: any) => (s.kind === 'hero' ? { ...s, title: 'Des portraits qui vous ressemblent' } : s));
  const put = await R.one.PUT(new Request('http://localhost/x', { method: 'PUT', body: JSON.stringify({ name: p.name, doc: { brief: p.brief, theme: { ...p.theme, palette: 'emeraude' }, seo: p.seo, sections } }) }), ctx(id));
  assert.equal(put.status, 200);
  assert.equal((await put.json()).project.sections[0].title, 'Des portraits qui vous ressemblent');

  // la réécriture IA est refusée proprement sans clé, et ne change rien
  const rw = await R.rewrite.POST(post('/x', { sectionId: sections[0].id, instruction: 'plus court' }), ctx(id));
  assert.equal(rw.status, 409);
  assert.equal((await rw.json()).error.code, 'no_ai');

  // 3. publication : fichiers statiques sur le disque
  const pub = await R.publish.POST(post('/x'), ctx(id));
  assert.equal(pub.status, 200);
  const result = await pub.json();
  assert.deepEqual(result.files.sort(), ['index.html', 'robots.txt', 'style.css']);
  const html = fs.readFileSync(path.join(result.dir, 'index.html'), 'utf8');
  assert.ok(html.includes('Des portraits qui vous ressemblent'));
  assert.match(fs.readFileSync(path.join(result.dir, 'style.css'), 'utf8'), /--accent:#047857/);
  assert.equal(path.dirname(result.dir), path.join(tmp, 'exports'), 'jamais en dehors du dossier de publication');

  // 4. téléchargement .zip valide (CRC vérifié)
  const { readZip } = await import('../src/lib/zip');
  const zipRes = await R.zip.GET(new Request('http://localhost/x'), ctx(id));
  assert.equal(zipRes.headers.get('content-type'), 'application/zip');
  const entries = readZip(Buffer.from(await zipRes.arrayBuffer()));
  assert.equal(entries['index.html'], html);

  // 5. export JSON puis import : l'utilisateur n'est pas piégé
  const exp = await R.exp.GET(new Request('http://localhost/x'), ctx(id));
  assert.match(exp.headers.get('content-disposition') ?? '', /studio-lumen\.hexsite\.json/);
  const file = await exp.json();
  const imp = await R.imp.POST(post('/api/projects/import', file));
  assert.equal(imp.status, 201);
  const imported = (await imp.json()).project;
  assert.notEqual(imported.id, id);
  assert.equal(imported.sections[0].title, 'Des portraits qui vous ressemblent');
  assert.equal((await R.imp.POST(post('/api/projects/import', { format: 'autre' }))).status, 400);

  // 6. exemples : créés, étiquetés, supprimés
  const sample = (await (await R.samples.POST()).json()).project;
  assert.ok(sample.name.startsWith('[EXEMPLE]'));
  assert.equal((await (await R.samples.DELETE()).json()).deleted, 1);

  // 7. suppression et état d'échec propre
  assert.equal((await R.one.DELETE(new Request('http://localhost/x', { method: 'DELETE' }), ctx(id))).status, 200);
  assert.equal((await R.one.GET(new Request('http://localhost/x'), ctx(id))).status, 404);
  assert.equal((await R.one.GET(new Request('http://localhost/x'), ctx('../../etc'))).status, 400);
  const list = await (await R.list.GET()).json();
  assert.equal(list.length, 1, 'il reste uniquement le site importé');
});

test('aucun secret ni contenu privé dans les journaux', async () => {
  process.env.ANTHROPIC_API_KEY = 'sk-ultra-secret-123';
  const logs: string[] = [];
  const orig = console.error;
  console.error = (...a: unknown[]) => { logs.push(a.join(' ')); };
  try {
    // route qui échoue en interne : corps invalide pour forcer le chemin d'erreur
    const res = await R.list.POST(new Request('http://localhost/api/projects', { method: 'POST', body: '{pas du json' }));
    assert.equal(res.status, 400);
    const health = await (await R.health.GET()).text();
    assert.ok(!health.includes('sk-ultra-secret-123'), 'la clé n’est jamais renvoyée au navigateur');
  } finally { console.error = orig; delete process.env.ANTHROPIC_API_KEY; }
  assert.ok(!logs.join('\n').includes('sk-ultra-secret-123'));
});
