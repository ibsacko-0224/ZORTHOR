import assert from 'node:assert/strict';
import { test } from 'node:test';
import { isSafeHref, parseImport, slugify, toExport, validateDoc, validateName, ValidationError } from '../src/lib/validate';
import { ruleBasedDoc } from '../src/lib/generator';
import type { Brief } from '../src/lib/types';

const brief: Brief = { name: 'Café Test', description: 'Un café. Des gâteaux maison. Ouvert aux voisins.', audience: 'Voisins', tone: 'chaleureux', language: 'fr', contactEmail: 'a@b.fr' };

test('un document valide passe, avec des identifiants de section uniques', () => {
  const doc = validateDoc(ruleBasedDoc(brief));
  assert.equal(doc.sections.length, 6);
  assert.equal(new Set(doc.sections.map((s) => s.id)).size, 6);
});

test('les liens dangereux sont refusés (javascript:, data:, //hôte)', () => {
  for (const bad of ['javascript:alert(1)', 'JaVaScRiPt:x', 'data:text/html,x', '//evil.example', 'ftp://x.y']) assert.equal(isSafeHref(bad), false, bad);
  for (const ok of ['', '#contact', '/page', 'https://exemple.fr/a?b=1', 'mailto:a@b.fr', 'tel:+33 1 23 45 67 89']) assert.equal(isSafeHref(ok), true, ok);
  const doc = ruleBasedDoc(brief);
  (doc.sections[0] as { ctaHref: string }).ctaHref = 'javascript:alert(1)';
  assert.throws(() => validateDoc(doc), (e: unknown) => e instanceof ValidationError && e.issues.some((i) => i.includes('lien invalide')));
});

test('toutes les erreurs sont remontées, avec le chemin du champ', () => {
  const doc = ruleBasedDoc(brief);
  (doc.sections[1] as { title: string }).title = '';
  (doc as { sections: unknown[] }).sections.push({ kind: 'inconnue' });
  try { validateDoc(doc); assert.fail('aurait dû échouer'); } catch (e) {
    assert.ok(e instanceof ValidationError);
    assert.ok(e.issues.some((i) => i.startsWith('sections[1].title')));
    assert.ok(e.issues.some((i) => i.includes('type de section inconnu')));
  }
});

test('limites : trop de sections, texte trop long, caractères de contrôle retirés', () => {
  const doc = ruleBasedDoc(brief);
  (doc.sections[0] as { title: string }).title = 'x'.repeat(500);
  assert.throws(() => validateDoc(doc), ValidationError);
  const d2 = ruleBasedDoc(brief);
  (d2.sections[2] as { body: string }).body = 'bon\u0000jour\u0007';
  assert.equal((validateDoc(d2).sections[2] as { body: string }).body, 'bonjour');
  const d3 = ruleBasedDoc(brief);
  d3.sections = Array.from({ length: 31 }, () => d3.sections[2]);
  assert.throws(() => validateDoc(d3), ValidationError);
});

test('nom : requis et borné ; slug sûr', () => {
  assert.throws(() => validateName('   '), ValidationError);
  assert.throws(() => validateName('x'.repeat(81)), ValidationError);
  assert.equal(slugify('Café d’Été !'), 'cafe-d-ete');
  assert.equal(slugify('../../etc'), 'etc');
  assert.equal(slugify('***'), 'site');
});

test('export puis import : aller-retour sans perte, et rejet des fichiers étrangers', () => {
  const doc = validateDoc(ruleBasedDoc(brief));
  const file = JSON.parse(JSON.stringify(toExport({ name: 'Café Test', ...doc })));
  const back = parseImport(file);
  assert.equal(back.name, 'Café Test');
  assert.deepEqual(back.doc.sections, doc.sections);
  assert.throws(() => parseImport({ format: 'autre' }), ValidationError);
  assert.throws(() => parseImport({ ...file, version: 2 }), ValidationError);
});
