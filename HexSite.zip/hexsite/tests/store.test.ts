import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { after, before, test } from 'node:test';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'hexsite-store-'));
process.env.DATA_DIR = tmp;

let S: typeof import('../src/lib/store');
let G: typeof import('../src/lib/generator');
let X: typeof import('../src/lib/samples');
before(async () => { S = await import('../src/lib/store'); G = await import('../src/lib/generator'); X = await import('../src/lib/samples'); });
after(() => fs.rmSync(tmp, { recursive: true, force: true }));

const brief = { name: 'Mon Atelier', description: 'Atelier de menuiserie. Meubles sur mesure.', audience: '', tone: 'direct' as const, language: 'fr' as const, contactEmail: '' };

test('création, lecture, mise à jour, suppression dans SQLite', () => {
  const p = S.createProject('Mon Atelier', G.ruleBasedDoc(brief));
  assert.equal(p.slug, 'mon-atelier');
  assert.equal(p.sections.length, 6);
  const doc = { brief: p.brief, theme: { ...p.theme, palette: 'rouge' as const }, seo: p.seo, sections: p.sections };
  const u = S.updateProject(p.id, { name: 'Nouveau nom', doc });
  assert.equal(u.name, 'Nouveau nom');
  assert.equal(u.theme.palette, 'rouge');
  assert.ok(u.updatedAt >= p.updatedAt);
  S.deleteProject(p.id);
  assert.equal(S.getProject(p.id), null);
});

test('slugs uniques et rejet des identifiants invalides', () => {
  const a = S.createProject('Doublon', G.ruleBasedDoc(brief));
  const b = S.createProject('Doublon', G.ruleBasedDoc(brief));
  assert.equal(a.slug, 'doublon');
  assert.equal(b.slug, 'doublon-2');
  assert.throws(() => S.getProject('../../etc'), /Identifiant invalide/);
});

test('une mise à jour invalide est refusée et ne modifie rien', () => {
  const p = S.createProject('Intact', G.ruleBasedDoc(brief));
  const bad = { brief: p.brief, theme: p.theme, seo: p.seo, sections: [{ kind: 'hero', title: '', ctaHref: 'javascript:x' }] };
  assert.throws(() => S.updateProject(p.id, { doc: bad }));
  assert.deepEqual(S.requireProject(p.id).sections, p.sections);
});

test('les exemples sont étiquetés et se suppriment sans toucher aux vrais sites', () => {
  const real = S.createProject('Vrai site', G.ruleBasedDoc(brief));
  const sample = S.createProject(X.SAMPLE_NAME, X.sampleDoc(), true);
  assert.ok(sample.name.startsWith('[EXEMPLE]'));
  assert.equal(sample.isSample, true);
  assert.ok(S.deleteSamples() >= 1);
  assert.equal(S.getProject(sample.id), null);
  assert.ok(S.getProject(real.id));
});
