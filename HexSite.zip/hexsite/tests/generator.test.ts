import assert from 'node:assert/strict';
import { test } from 'node:test';
import { aiGenerate, aiRewriteSection, AiError, extractJson } from '../src/lib/ai';
import { generateDoc, ruleBasedDoc } from '../src/lib/generator';
import type { Brief } from '../src/lib/types';

const brief: Brief = { name: 'Studio Lumen', description: 'Photographe de portraits. Séances en studio. Retouches incluses.', audience: 'Particuliers', tone: 'professionnel', language: 'fr', contactEmail: 'hello@lumen.test' };
const cfg = { apiKey: 'sk-test-secret', model: 'modele-test' };

const aiJson = JSON.stringify({
  seo: { title: 'Studio Lumen', description: 'Portraits en studio.' },
  sections: [
    { kind: 'hero', eyebrow: '', title: 'Des portraits qui vous ressemblent', subtitle: 'Séances en studio.', ctaLabel: 'Réserver', ctaHref: 'mailto:hello@lumen.test' },
    { kind: 'about', title: 'À propos', body: 'Photographe de portraits.' },
    { kind: 'footer', brand: 'Studio Lumen', text: '', links: [] },
  ],
});
const reply = (text: string, status = 200) => async () => new Response(JSON.stringify({ content: [{ type: 'text', text }] }), { status });

test('mode sans IA : déterministe, sans fait inventé, marqué « À compléter » quand il manque du contenu', () => {
  const fixed = new Date('2026-01-01T00:00:00Z');
  const a = ruleBasedDoc(brief, undefined, fixed);
  assert.deepEqual(a.sections.map((s) => s.kind), ['hero', 'features', 'about', 'faq', 'cta', 'footer']);
  assert.equal((a.sections[0] as { title: string }).title, 'Studio Lumen');
  assert.ok((a.sections[0] as { ctaHref: string }).ctaHref.startsWith('mailto:hello@lumen.test'));
  const short = ruleBasedDoc({ ...brief, description: 'Un seul phrase.', audience: '' });
  assert.ok(JSON.stringify(short).includes('À compléter'));
  assert.ok(!JSON.stringify(a).match(/témoignage|€|\d+ ans|certifi/i), 'aucun témoignage, prix ou certification inventé');
});

test('sans clé : generateDoc reste fonctionnel et le dit', async () => {
  const g = await generateDoc(brief, { ai: null });
  assert.equal(g.mode, 'degraded');
  assert.match(g.note, /sans IA/);
  assert.equal(g.doc.sections.length, 6);
});

test('avec IA (réponse simulée) : le contenu est validé puis accepté, la clé n’apparaît pas dans le résultat', async () => {
  const g = await generateDoc(brief, { ai: cfg, fetchFn: reply('```json\n' + aiJson + '\n```') });
  assert.equal(g.mode, 'ai');
  assert.equal(g.doc.sections.length, 3);
  assert.ok(!JSON.stringify(g).includes('sk-test-secret'));
});

test('IA en échec ou réponse invalide : repli automatique sans IA, avec une note claire', async () => {
  for (const f of [reply('pas du json'), reply('{"sections":[{"kind":"hero","title":""}]}'), reply('', 500), reply('x', 401), async () => { throw new Error('réseau'); }]) {
    const g = await generateDoc(brief, { ai: cfg, fetchFn: f as never });
    assert.equal(g.mode, 'degraded');
    assert.match(g.note, /L’IA a échoué/);
    assert.equal(g.doc.sections.length, 6);
    assert.ok(!g.note.includes('sk-test-secret'));
  }
});

test('l’IA ne peut pas injecter de lien dangereux', async () => {
  const evil = aiJson.replace('mailto:hello@lumen.test', 'javascript:alert(1)');
  await assert.rejects(aiGenerate(cfg, brief, { theme: ruleBasedDoc(brief).theme }, reply(evil)), AiError);
});

test('réécriture d’une section : type et identifiant conservés', async () => {
  const doc = ruleBasedDoc(brief);
  const target = doc.sections[2];
  const out = await aiRewriteSection(cfg, doc, target.id, 'plus court', reply(JSON.stringify({ kind: 'hero', title: 'Nouveau titre', body: 'Texte court.' })));
  assert.equal(out.kind, 'about');
  assert.equal(out.id, target.id);
  assert.equal((out as { body: string }).body, 'Texte court.');
});

test('extractJson tolère le texte autour et les blocs de code', () => {
  assert.deepEqual(extractJson('Voici : ```json\n{"a":1}\n``` fin'), { a: 1 });
  assert.throws(() => extractJson('rien'), AiError);
});
