import assert from 'node:assert/strict';
import { test } from 'node:test';
import { renderFiles, previewHtml } from '../src/lib/render';
import { ruleBasedDoc } from '../src/lib/generator';
import { sampleDoc } from '../src/lib/samples';

const doc = sampleDoc();

test('le HTML publié est autonome, accessible et responsive', () => {
  const f = renderFiles(doc, 'Atelier');
  const html = f['index.html'];
  assert.match(html, /<html lang="fr">/);
  assert.match(html, /name="viewport"/);
  assert.match(html, /<main id="main">/);
  assert.match(html, /class="skip"/);
  assert.match(html, /<h1>/);
  assert.equal((html.match(/<h1>/g) ?? []).length, 1, 'un seul h1');
  assert.match(f['style.css'], /@media \(max-width:640px\)/);
  assert.match(f['style.css'], /:focus-visible/);
  assert.match(f['style.css'], /prefers-reduced-motion/);
  assert.ok(!/<script/i.test(html), 'aucun script');
  assert.ok(!/(src|href)="https?:\/\/(?!exemple)/i.test(html.replace(/mailto:[^"]+/g, '')), 'aucune ressource externe');
  assert.deepEqual(Object.keys(f).sort(), ['index.html', 'robots.txt', 'style.css']);
});

test('le texte saisi est échappé : pas d’injection HTML', () => {
  const d = ruleBasedDoc({ name: '<img src=x onerror=alert(1)>', description: 'A "quote" & <b>gras</b>', audience: '', tone: 'direct', language: 'fr', contactEmail: '' });
  const html = renderFiles(d, 'X <script>alert(1)</script>')['index.html'];
  assert.ok(!html.includes('<img src=x'));
  assert.ok(!html.includes('<script>alert'));
  assert.ok(html.includes('&lt;img src=x onerror=alert(1)&gt;'));
});

test('un lien non sûr ne sort jamais dans le HTML', () => {
  const d = structuredClone(doc);
  (d.sections[0] as { ctaHref: string }).ctaHref = 'javascript:alert(1)';
  assert.ok(!renderFiles(d, 'X')['index.html'].includes('javascript:'));
});

test('thèmes : mode sombre et palette appliqués ; aperçu avec CSS intégré et liens neutralisés', () => {
  const dark = structuredClone(doc);
  dark.theme = { palette: 'violet', font: 'sans', mode: 'dark' };
  assert.match(renderFiles(dark, 'X')['style.css'], /--bg:#0B1020/);
  assert.match(renderFiles(dark, 'X')['style.css'], /--accent:#6D28D9/);
  const p = previewHtml(doc, 'X');
  assert.ok(p.includes('<style>'));
  assert.ok(!p.includes('<link rel="stylesheet"'));
  assert.ok(p.includes('<base target="_blank">'));
});
