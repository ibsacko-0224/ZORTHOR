/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  // Aucune télémétrie : désactivée aussi via NEXT_TELEMETRY_DISABLED dans .env.example et les scripts.
};
export default nextConfig;
