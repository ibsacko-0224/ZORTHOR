export type ApiResult<T> = { ok: true; data: T } | { ok: false; error: string; issues?: string[]; code?: string; offline?: boolean };

/** fetch qui ne jette jamais : l'interface affiche toujours un état d'échec récupérable. */
export async function api<T = unknown>(url: string, init?: RequestInit): Promise<ApiResult<T>> {
  try {
    const res = await fetch(url, init);
    const body = await res.json().catch(() => null);
    if (!res.ok) return { ok: false, error: body?.error?.message ?? `Erreur du serveur (${res.status}).`, issues: body?.error?.issues, code: body?.error?.code };
    return { ok: true, data: body as T };
  } catch {
    return { ok: false, offline: true, error: 'Le serveur local ne répond pas. Vérifiez que « npm run dev » ou « npm run start » tourne toujours.' };
  }
}

export const jsonInit = (method: string, body?: unknown): RequestInit => ({
  method, headers: { 'content-type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body),
});
