'use client';
import { useId } from 'react';
import type { Section } from '../lib/types';

function Field({ label, value, onChange, multiline, max, hint }: { label: string; value: string; onChange: (v: string) => void; multiline?: boolean; max?: number; hint?: string }) {
  const id = useId();
  return (
    <>
      <label htmlFor={id}>{label}</label>
      {multiline
        ? <textarea id={id} value={value} maxLength={max} onChange={(e) => onChange(e.target.value)} aria-describedby={hint ? `${id}-h` : undefined} />
        : <input id={id} value={value} maxLength={max} onChange={(e) => onChange(e.target.value)} aria-describedby={hint ? `${id}-h` : undefined} />}
      {hint && <p id={`${id}-h`} className="muted" style={{ margin: '.2rem 0 0', fontSize: '.85rem' }}>{hint}</p>}
    </>
  );
}

const LINK_HINT = 'https://…, mailto:…, tel:…, #ancre ou /chemin';

function Items<T>({ title, items, make, render, onChange, max = 12 }: { title: string; items: T[]; make: () => T; render: (it: T, set: (p: Partial<T>) => void, i: number) => React.ReactNode; onChange: (items: T[]) => void; max?: number }) {
  return (
    <fieldset style={{ border: 0, padding: 0, margin: '1rem 0 0' }}>
      <legend><h3>{title}</h3></legend>
      {items.map((it, i) => (
        <div className="item" key={i}>
          <div className="row"><strong className="grow">Élément {i + 1}</strong>
            <button type="button" disabled={i === 0} aria-label={`Monter l’élément ${i + 1}`} onClick={() => { const n = [...items]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; onChange(n); }}>↑</button>
            <button type="button" disabled={i === items.length - 1} aria-label={`Descendre l’élément ${i + 1}`} onClick={() => { const n = [...items]; [n[i + 1], n[i]] = [n[i], n[i + 1]]; onChange(n); }}>↓</button>
            <button type="button" className="danger" aria-label={`Supprimer l’élément ${i + 1}`} onClick={() => onChange(items.filter((_, j) => j !== i))}>Supprimer</button>
          </div>
          {render(it, (p) => onChange(items.map((x, j) => (j === i ? { ...x, ...p } : x))), i)}
        </div>
      ))}
      <button type="button" disabled={items.length >= max} onClick={() => onChange([...items, make()])}>Ajouter un élément</button>
    </fieldset>
  );
}

/** Formulaire d'édition d'une section : un champ étiqueté par donnée, aucun HTML libre. */
export function SectionForm({ section, onChange }: { section: Section; onChange: (s: Section) => void }) {
  const s = section;
  switch (s.kind) {
    case 'hero':
      return (<>
        <Field label="Sur-titre (optionnel)" value={s.eyebrow} max={60} onChange={(v) => onChange({ ...s, eyebrow: v })} />
        <Field label="Titre" value={s.title} max={160} onChange={(v) => onChange({ ...s, title: v })} />
        <Field label="Sous-titre" value={s.subtitle} multiline max={600} onChange={(v) => onChange({ ...s, subtitle: v })} />
        <Field label="Texte du bouton" value={s.ctaLabel} max={60} onChange={(v) => onChange({ ...s, ctaLabel: v })} />
        <Field label="Lien du bouton" value={s.ctaHref} max={500} hint={LINK_HINT} onChange={(v) => onChange({ ...s, ctaHref: v })} />
      </>);
    case 'features':
      return (<>
        <Field label="Titre" value={s.title} max={160} onChange={(v) => onChange({ ...s, title: v })} />
        <Field label="Introduction" value={s.intro} multiline max={600} onChange={(v) => onChange({ ...s, intro: v })} />
        <Items title="Points forts" items={s.items} make={() => ({ title: 'Point fort', text: 'À compléter' })} onChange={(items) => onChange({ ...s, items })}
          render={(it, set) => (<><Field label="Titre" value={it.title} max={160} onChange={(v) => set({ title: v })} /><Field label="Texte" value={it.text} multiline max={600} onChange={(v) => set({ text: v })} /></>)} />
      </>);
    case 'about':
      return (<>
        <Field label="Titre" value={s.title} max={160} onChange={(v) => onChange({ ...s, title: v })} />
        <Field label="Texte" value={s.body} multiline max={3000} hint="Une ligne vide sépare deux paragraphes." onChange={(v) => onChange({ ...s, body: v })} />
      </>);
    case 'faq':
      return (<>
        <Field label="Titre" value={s.title} max={160} onChange={(v) => onChange({ ...s, title: v })} />
        <Items title="Questions" items={s.items} make={() => ({ q: 'Question ?', a: 'Réponse à compléter' })} onChange={(items) => onChange({ ...s, items })}
          render={(it, set) => (<><Field label="Question" value={it.q} max={160} onChange={(v) => set({ q: v })} /><Field label="Réponse" value={it.a} multiline max={3000} onChange={(v) => set({ a: v })} /></>)} />
      </>);
    case 'cta':
      return (<>
        <Field label="Titre" value={s.title} max={160} onChange={(v) => onChange({ ...s, title: v })} />
        <Field label="Texte" value={s.text} multiline max={600} onChange={(v) => onChange({ ...s, text: v })} />
        <Field label="Texte du bouton" value={s.buttonLabel} max={60} onChange={(v) => onChange({ ...s, buttonLabel: v })} />
        <Field label="Lien du bouton" value={s.buttonHref} max={500} hint={LINK_HINT} onChange={(v) => onChange({ ...s, buttonHref: v })} />
      </>);
    case 'footer':
      return (<>
        <Field label="Nom affiché" value={s.brand} max={80} onChange={(v) => onChange({ ...s, brand: v })} />
        <Field label="Texte" value={s.text} multiline max={600} onChange={(v) => onChange({ ...s, text: v })} />
        <Items title="Liens" items={s.links} max={12} make={() => ({ label: 'Lien', href: '#' })} onChange={(links) => onChange({ ...s, links })}
          render={(it, set) => (<><Field label="Texte" value={it.label} max={60} onChange={(v) => set({ label: v })} /><Field label="Adresse" value={it.href} max={500} hint={LINK_HINT} onChange={(v) => set({ href: v })} /></>)} />
      </>);
  }
}
