'use client';
import Link from 'next/link';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { blankSection } from '../lib/blank';
import { previewHtml } from '../lib/render';
import { KIND_LABELS, PALETTES, SECTION_KINDS, type Doc, type SectionKind } from '../lib/types';
import { api, jsonInit } from './api';
import { SectionForm } from './SectionForm';

type P = Doc & { id: string; name: string; slug: string };
type Tab = 'edit' | 'preview' | 'publish';
type Save = { state: 'saved' | 'dirty' | 'saving' | 'error'; message?: string; issues?: string[] };
type Pub = { s: 'idle' } | { s: 'busy' } | { s: 'ok'; dir: string; files: string[]; bytes: number } | { s: 'err'; msg: string };

const BREAKPOINTS = [{ id: 'desktop', label: 'Ordinateur', w: 1280 }, { id: 'tablet', label: 'Tablette', w: 820 }, { id: 'mobile', label: 'Mobile', w: 390 }] as const;
const PALETTE_LABEL: Record<string, string> = { bleu: 'Bleu', emeraude: 'Émeraude', rouge: 'Rouge', violet: 'Violet', ambre: 'Ambre', ardoise: 'Ardoise' };

const sectionTitle = (s: Doc['sections'][number]) => ('title' in s ? s.title : 'brand' in s ? s.brand : '') || KIND_LABELS[s.kind];

export function Editor({ id }: { id: string }) {
  const [phase, setPhase] = useState<'loading' | 'ready' | 'error'>('loading');
  const [loadError, setLoadError] = useState('');
  const [name, setName] = useState('');
  const [doc, setDoc] = useState<Doc | null>(null);
  const [sel, setSel] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>('edit');
  const [bp, setBp] = useState<(typeof BREAKPOINTS)[number]['id']>('desktop');
  const [save, setSave] = useState<Save>({ state: 'saved' });
  const [ai, setAi] = useState(false);
  const [instruction, setInstruction] = useState('');
  const [aiBusy, setAiBusy] = useState(false);
  const [aiMsg, setAiMsg] = useState<{ kind: 'ok' | 'bad'; text: string } | null>(null);
  const [pub, setPub] = useState<Pub>({ s: 'idle' });
  const [newKind, setNewKind] = useState<SectionKind>('features');
  const [viewW, setViewW] = useState(900);

  const docRef = useRef<Doc | null>(null);
  const nameRef = useRef('');
  const ver = useRef(0);
  const timer = useRef<number | undefined>(undefined);
  const viewRef = useRef<HTMLDivElement>(null);

  const load = useCallback(async () => {
    setPhase('loading');
    const [r, h] = await Promise.all([api<P>(`/api/projects/${id}`), api<{ ai: { configured: boolean } }>('/api/health')]);
    if (h.ok) setAi(h.data.ai.configured);
    if (!r.ok) { setLoadError(r.error); setPhase('error'); return; }
    const { brief, theme, seo, sections } = r.data;
    const d = { brief, theme, seo, sections };
    docRef.current = d; nameRef.current = r.data.name;
    setDoc(d); setName(r.data.name); setSel(sections[0]?.id ?? null); setPhase('ready');
  }, [id]);
  useEffect(() => { load(); }, [load]);

  // ───── enregistrement automatique
  const flush = useCallback(async (): Promise<boolean> => {
    window.clearTimeout(timer.current);
    const d = docRef.current;
    if (!d) return false;
    const v = ver.current;
    setSave({ state: 'saving' });
    const r = await api(`/api/projects/${id}`, jsonInit('PUT', { name: nameRef.current, doc: d }));
    if (!r.ok) {
      setSave({ state: 'error', message: r.error, issues: r.issues });
      if (r.offline) timer.current = window.setTimeout(() => { flush(); }, 5000);
      return false;
    }
    if (ver.current !== v) return flush();
    setSave({ state: 'saved' });
    return true;
  }, [id]);

  const markDirty = useCallback(() => {
    ver.current++;
    setSave({ state: 'dirty' });
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => { flush(); }, 800);
  }, [flush]);

  const apply = useCallback((next: Doc) => { docRef.current = next; setDoc(next); markDirty(); }, [markDirty]);

  useEffect(() => {
    const h = (e: BeforeUnloadEvent) => { if (save.state === 'dirty' || save.state === 'error') e.preventDefault(); };
    window.addEventListener('beforeunload', h);
    return () => window.removeEventListener('beforeunload', h);
  }, [save.state]);

  useEffect(() => {
    const el = viewRef.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setViewW(el.clientWidth));
    ro.observe(el); setViewW(el.clientWidth);
    return () => ro.disconnect();
  }, [tab, phase]);

  const bpw = BREAKPOINTS.find((b) => b.id === bp)!.w;
  const scale = Math.min(1, viewW / bpw);
  const html = useMemo(() => (doc && tab === 'preview' ? previewHtml(doc, name) : ''), [doc, name, tab]);

  if (phase === 'loading') return <main className="wrap"><p role="status" className="skeleton">Ouverture du site…</p></main>;
  if (phase === 'error' || !doc) {
    return <main className="wrap"><div className="alert bad" role="alert"><strong>Impossible d’ouvrir ce site.</strong> {loadError}</div>
      <p><button className="primary" onClick={load}>Réessayer</button> <Link className="btn" href="/">Retour à mes sites</Link></p></main>;
  }

  const section = doc.sections.find((s) => s.id === sel) ?? null;
  const move = (i: number, d: -1 | 1) => { const n = [...doc.sections]; [n[i], n[i + d]] = [n[i + d], n[i]]; apply({ ...doc, sections: n }); };
  const remove = (sid: string) => { if (doc.sections.length <= 1) return; apply({ ...doc, sections: doc.sections.filter((s) => s.id !== sid) }); if (sel === sid) setSel(null); };
  const add = () => { const s = blankSection(newKind); apply({ ...doc, sections: [...doc.sections, s] }); setSel(s.id); };

  async function rewrite() {
    if (!section) return;
    setAiBusy(true); setAiMsg(null);
    const ok = await flush();
    if (!ok) { setAiBusy(false); setAiMsg({ kind: 'bad', text: 'Enregistrement impossible : corrigez d’abord l’erreur indiquée.' }); return; }
    const r = await api<{ project: P }>(`/api/projects/${id}/rewrite`, jsonInit('POST', { sectionId: section.id, instruction }));
    setAiBusy(false);
    if (!r.ok) { setAiMsg({ kind: 'bad', text: r.error }); return; }
    const { brief, theme, seo, sections } = r.data.project;
    const d = { brief, theme, seo, sections };
    docRef.current = d; setDoc(d);
    setAiMsg({ kind: 'ok', text: 'Section réécrite par l’IA : relisez-la, elle peut contenir des erreurs.' });
  }

  async function regenerate() {
    if (!confirm('Régénérer toutes les sections à partir du brief ? Vos modifications manuelles seront remplacées.')) return;
    const r = await api<{ project: P; note: string }>(`/api/projects/${id}/regenerate`, jsonInit('POST'));
    if (!r.ok) { setAiMsg({ kind: 'bad', text: r.error }); return; }
    const { brief, theme, seo, sections } = r.data.project;
    const d = { brief, theme, seo, sections };
    docRef.current = d; setDoc(d); setSel(sections[0]?.id ?? null);
    setAiMsg({ kind: 'ok', text: r.data.note });
  }

  async function publish() {
    setPub({ s: 'busy' });
    if (!(await flush())) { setPub({ s: 'err', msg: 'Le site n’a pas pu être enregistré : corrigez l’erreur d’enregistrement puis réessayez.' }); return; }
    const r = await api<{ dir: string; files: string[]; bytes: number }>(`/api/projects/${id}/publish`, jsonInit('POST'));
    setPub(r.ok ? { s: 'ok', ...r.data } : { s: 'err', msg: r.error });
  }

  const saveLabel = { saved: 'Enregistré', dirty: 'Modifications en attente…', saving: 'Enregistrement…', error: 'Non enregistré' }[save.state];

  return (
    <main className="wrap">
      <div className="row">
        <Link href="/" className="btn">← Mes sites</Link>
        <div className="grow"><label htmlFor="nm" className="muted" style={{ margin: 0, fontWeight: 400 }}>Nom du site</label>
          <input id="nm" value={name} maxLength={80} onChange={(e) => { setName(e.target.value); nameRef.current = e.target.value; markDirty(); }} /></div>
        <span role="status" className={`chip ${save.state === 'saved' ? 'ok' : save.state === 'error' ? 'warn' : ''}`}>{saveLabel}</span>
        {save.state === 'error' && <button onClick={() => flush()}>Réessayer</button>}
      </div>
      {save.state === 'error' && (
        <div className="alert bad" role="alert">{save.message}{save.issues && <ul>{save.issues.map((i) => <li key={i}>{i}</li>)}</ul>}</div>)}

      <div className="tabs" role="tablist" aria-label="Étapes">
        {([['edit', 'Modifier'], ['preview', 'Aperçu'], ['publish', 'Publier']] as [Tab, string][]).map(([k, l]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}>{l}</button>))}
      </div>

      {tab === 'edit' && (
        <div className="cols">
          <aside className="panel side" aria-label="Sections">
            <h2>Sections</h2>
            {doc.sections.map((s, i) => (
              <div className="sec" key={s.id}>
                <button type="button" className={s.id === sel ? 'sel' : ''} aria-pressed={s.id === sel} onClick={() => setSel(s.id)}>{KIND_LABELS[s.kind]} · {sectionTitle(s)}</button>
                <button type="button" disabled={i === 0} aria-label={`Monter la section ${KIND_LABELS[s.kind]}`} onClick={() => move(i, -1)}>↑</button>
                <button type="button" disabled={i === doc.sections.length - 1} aria-label={`Descendre la section ${KIND_LABELS[s.kind]}`} onClick={() => move(i, 1)}>↓</button>
                <button type="button" className="danger" disabled={doc.sections.length <= 1} aria-label={`Supprimer la section ${KIND_LABELS[s.kind]}`} onClick={() => remove(s.id)}>✕</button>
              </div>))}
            <label htmlFor="nk">Ajouter une section</label>
            <select id="nk" value={newKind} onChange={(e) => setNewKind(e.target.value as SectionKind)}>{SECTION_KINDS.map((k) => <option key={k} value={k}>{KIND_LABELS[k]}</option>)}</select>
            <p><button type="button" onClick={add}>Ajouter</button></p>
          </aside>

          <div>
            <section className="panel" aria-labelledby="sec-h">
              <h2 id="sec-h">{section ? KIND_LABELS[section.kind] : 'Section'}</h2>
              {section
                ? <SectionForm section={section} onChange={(s) => apply({ ...doc, sections: doc.sections.map((x) => (x.id === s.id ? s : x)) })} />
                : <p className="muted">Choisissez une section dans la liste.</p>}
              {section && (
                <div style={{ marginTop: '1.2rem' }}>
                  <h3>Réécrire avec l’IA</h3>
                  {!ai && <p className="muted">Désactivé : aucune clé IA configurée (<code>ANTHROPIC_API_KEY</code> dans <code>.env</code>). Modifiez la section à la main, ou voir le README (« Mode sans IA »).</p>}
                  <label htmlFor="ins">Consigne (ex. « plus court », « ton plus direct »)</label>
                  <input id="ins" value={instruction} maxLength={400} disabled={!ai} onChange={(e) => setInstruction(e.target.value)} />
                  <p><button disabled={!ai || aiBusy || !instruction.trim()} onClick={rewrite}>{aiBusy ? 'Réécriture…' : 'Réécrire cette section'}</button></p>
                </div>)}
              {aiMsg && <div className={`alert ${aiMsg.kind}`} role={aiMsg.kind === 'bad' ? 'alert' : 'status'}>{aiMsg.text}</div>}
            </section>

            <section className="panel" aria-labelledby="th">
              <h2 id="th">Apparence et référencement</h2>
              <div className="row">
                <div className="grow"><label htmlFor="pal">Couleur</label>
                  <select id="pal" value={doc.theme.palette} onChange={(e) => apply({ ...doc, theme: { ...doc.theme, palette: e.target.value as never } })}>{PALETTES.map((p) => <option key={p} value={p}>{PALETTE_LABEL[p]}</option>)}</select></div>
                <div className="grow"><label htmlFor="fnt">Police</label>
                  <select id="fnt" value={doc.theme.font} onChange={(e) => apply({ ...doc, theme: { ...doc.theme, font: e.target.value as never } })}><option value="sans">Sans empattement</option><option value="serif">Avec empattement</option></select></div>
                <div className="grow"><label htmlFor="mod">Mode</label>
                  <select id="mod" value={doc.theme.mode} onChange={(e) => apply({ ...doc, theme: { ...doc.theme, mode: e.target.value as never } })}><option value="light">Clair</option><option value="dark">Sombre</option></select></div>
              </div>
              <label htmlFor="st">Titre de la page (SEO)</label>
              <input id="st" value={doc.seo.title} maxLength={120} onChange={(e) => apply({ ...doc, seo: { ...doc.seo, title: e.target.value } })} />
              <label htmlFor="sd">Description (SEO)</label>
              <textarea id="sd" value={doc.seo.description} maxLength={300} onChange={(e) => apply({ ...doc, seo: { ...doc.seo, description: e.target.value } })} />
              <p><button type="button" className="danger" onClick={regenerate}>Régénérer toutes les sections depuis le brief</button></p>
            </section>
          </div>
        </div>)}

      {tab === 'preview' && (
        <section className="panel" aria-labelledby="pv">
          <h2 id="pv">Aperçu responsive</h2>
          <div role="radiogroup" aria-label="Largeur d’aperçu" className="row">
            {BREAKPOINTS.map((b) => (
              <button key={b.id} role="radio" aria-checked={bp === b.id} className={bp === b.id ? 'primary' : ''} onClick={() => setBp(b.id)}>{b.label} ({b.w} px)</button>))}
          </div>
          <p className="muted">Largeur réelle simulée : {bpw} px (zoom {Math.round(scale * 100)} %). C’est exactement le code qui sera publié.</p>
          <div ref={viewRef} className="frame-wrap" style={{ height: 760 * scale }}>
            <iframe title={`Aperçu du site, largeur ${bpw} pixels`} sandbox="" srcDoc={html}
              style={{ width: bpw, height: 760, border: 0, transform: `scale(${scale})`, transformOrigin: '0 0' }} />
          </div>
        </section>)}

      {tab === 'publish' && (
        <section className="panel" aria-labelledby="pb">
          <h2 id="pb">Publier</h2>
          <p className="muted">Écrit les fichiers statiques (<code>index.html</code>, <code>style.css</code>, <code>robots.txt</code>) dans le dossier <code>PUBLISH_DIR</code> de votre machine. Aucun hébergement n’est fourni : copiez le dossier ou le .zip où vous voulez.</p>
          <div className="row">
            <button className="primary" onClick={publish} disabled={pub.s === 'busy'}>{pub.s === 'busy' ? 'Publication…' : 'Publier le site'}</button>
            <a className="btn" href={`/api/projects/${id}/zip`} download>Télécharger le .zip</a>
            <a className="btn" href={`/api/projects/${id}/export`} download>Exporter (JSON)</a>
          </div>
          <div aria-live="polite">
            {pub.s === 'ok' && <div className="alert ok" role="status"><strong>Site publié.</strong><br />Dossier : <code>{pub.dir}</code><br />{pub.files.length} fichiers, {pub.bytes} octets ({pub.files.join(', ')}).</div>}
            {pub.s === 'err' && <div className="alert bad" role="alert"><strong>La publication a échoué.</strong> {pub.msg} <button onClick={publish}>Réessayer</button></div>}
          </div>
        </section>)}
    </main>
  );
}
