import { NextResponse, type NextRequest } from 'next/server';

/** Mode privé : les requêtes d'écriture venant d'une autre origine (page tierce ouverte dans votre navigateur) sont refusées. */
export function middleware(req: NextRequest) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return NextResponse.next();
  const deny = () => NextResponse.json({ error: { code: 'forbidden_origin', message: 'Origine refusée.' } }, { status: 403 });
  const origin = req.headers.get('origin');
  if (origin) {
    try { if (new URL(origin).host !== req.headers.get('host')) return deny(); } catch { return deny(); }
  }
  if (req.headers.get('sec-fetch-site') === 'cross-site') return deny();
  return NextResponse.next();
}

export const config = { matcher: '/api/:path*' };
