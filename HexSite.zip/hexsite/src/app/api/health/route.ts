import { aiConfig } from '../../../lib/env';
import { handle, json } from '../../../lib/http';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** État de l'IA optionnelle. La clé n'est jamais renvoyée. */
export const GET = handle(async () => {
  const ai = aiConfig();
  return json({ ok: true, ai: ai ? { configured: true, model: ai.model } : { configured: false } });
});
