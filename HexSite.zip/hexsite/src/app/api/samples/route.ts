import { handle, json } from '../../../lib/http';
import { sampleDoc, SAMPLE_NAME } from '../../../lib/samples';
import { createProject, deleteSamples } from '../../../lib/store';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const POST = handle(async () => json({ project: createProject(SAMPLE_NAME, sampleDoc(), true) }, 201));
export const DELETE = handle(async () => json({ deleted: deleteSamples() }));
