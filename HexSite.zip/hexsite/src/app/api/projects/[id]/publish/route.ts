import { handle, json } from '../../../../../lib/http';
import { publishProject } from '../../../../../lib/publish';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const POST = handle(async (_req: Request, { params }: { params: Promise<{ id: string }> }) => json(publishProject((await params).id)));
