import { handle } from '../../../../../lib/http';
import { requireProject } from '../../../../../lib/store';
import { toExport } from '../../../../../lib/validate';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = handle(async (_req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const p = requireProject((await params).id);
  return new Response(JSON.stringify(toExport(p)), {
    headers: { 'content-type': 'application/json; charset=utf-8', 'content-disposition': `attachment; filename="${p.slug}.hexsite.json"`, 'cache-control': 'no-store' },
  });
});
