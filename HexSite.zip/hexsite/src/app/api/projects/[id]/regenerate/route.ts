import { aiConfig } from '../../../../../lib/env';
import { generateDoc } from '../../../../../lib/generator';
import { handle, json } from '../../../../../lib/http';
import { requireProject, updateProject } from '../../../../../lib/store';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** Régénère toutes les sections à partir du brief (remplace les modifications manuelles : le client demande confirmation). */
export const POST = handle(async (_req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const p = requireProject((await params).id);
  const gen = await generateDoc(p.brief, { ai: aiConfig(), theme: p.theme });
  return json({ project: updateProject(p.id, { doc: gen.doc }), mode: gen.mode, note: gen.note });
});
