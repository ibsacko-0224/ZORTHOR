import { aiRewriteSection, AiError } from '../../../../../lib/ai';
import { aiConfig } from '../../../../../lib/env';
import { AppError, handle, json, readJson } from '../../../../../lib/http';
import { requireProject, updateProject } from '../../../../../lib/store';
import { ValidationError } from '../../../../../lib/validate';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/** Réécriture d'une section par l'IA (optionnelle). Sans clé : réponse 409 explicite, rien n'est modifié. */
export const POST = handle(async (req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const cfg = aiConfig();
  if (!cfg) throw new AppError(409, 'no_ai', 'Aucune clé IA configurée (ANTHROPIC_API_KEY dans .env) : modifiez la section à la main.');
  const body = (await readJson(req)) as { sectionId?: unknown; instruction?: unknown };
  const instruction = typeof body.instruction === 'string' ? body.instruction.trim() : '';
  if (!instruction || instruction.length > 400) throw new ValidationError(['consigne : 1 à 400 caractères']);
  if (typeof body.sectionId !== 'string') throw new ValidationError(['sectionId : requis']);
  const p = requireProject((await params).id);
  try {
    const section = await aiRewriteSection(cfg, p, body.sectionId, instruction);
    const doc = { brief: p.brief, theme: p.theme, seo: p.seo, sections: p.sections.map((s) => (s.id === section.id ? section : s)) };
    return json({ project: updateProject(p.id, { doc }) });
  } catch (e) {
    if (e instanceof AiError) throw new AppError(502, 'ai_failed', e.message);
    throw e;
  }
});
