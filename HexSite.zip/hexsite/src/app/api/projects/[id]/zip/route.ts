import { handle } from '../../../../../lib/http';
import { zipProject } from '../../../../../lib/publish';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = handle(async (_req: Request, { params }: { params: Promise<{ id: string }> }) => {
  const z = zipProject((await params).id);
  return new Response(new Uint8Array(z.data), {
    headers: { 'content-type': 'application/zip', 'content-disposition': `attachment; filename="${z.name}"`, 'cache-control': 'no-store' },
  });
});
