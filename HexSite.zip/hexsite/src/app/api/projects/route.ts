import { aiConfig } from '../../../lib/env';
import { generateDoc } from '../../../lib/generator';
import { handle, json, readJson } from '../../../lib/http';
import { createProject, listProjects } from '../../../lib/store';
import { parseBrief } from '../../../lib/validate';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const GET = handle(async () => json(listProjects()));

/** Crée un site à partir d'un brief : IA si une clé est configurée, sinon mode sans IA (indiqué dans la réponse). */
export const POST = handle(async (req: Request) => {
  const body = (await readJson(req)) as { brief?: unknown; theme?: unknown };
  const brief = parseBrief(body.brief);
  const gen = await generateDoc(brief, { ai: aiConfig(), theme: body.theme as never });
  const project = createProject(brief.name, gen.doc);
  return json({ project, mode: gen.mode, note: gen.note }, 201);
});
