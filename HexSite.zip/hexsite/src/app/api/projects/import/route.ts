import { handle, json, readJson } from '../../../../lib/http';
import { createProject } from '../../../../lib/store';
import { parseImport } from '../../../../lib/validate';
import { LIMITS } from '../../../../lib/types';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export const POST = handle(async (req: Request) => {
  const { name, doc } = parseImport(await readJson(req, LIMITS.importBytes));
  return json({ project: createProject(name, doc) }, 201);
});
