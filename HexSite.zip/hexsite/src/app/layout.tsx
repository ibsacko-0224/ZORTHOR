import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import './globals.css';

export const metadata: Metadata = {
  title: 'HexSite',
  description: 'Générateur de sites web : sections structurées, aperçu responsive, publication statique. Privé et local.',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <body>
        <a className="skip" href="#contenu">Aller au contenu</a>
        <div id="contenu">{children}</div>
      </body>
    </html>
  );
}
