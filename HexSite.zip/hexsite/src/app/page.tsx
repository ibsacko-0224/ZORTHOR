'use client';
import Link from 'next/link';
import { useCallback, useEffect, useRef, useState } from 'react';
import { api, jsonInit } from '../components/api';

type Row = { id: string; slug: string; name: string; isSample: boolean; sections: number; updatedAt: number };
type Health = { ai: { configured: boolean; model?: string } };
type Notice = { kind: 'ok' | 'bad' | 'info'; text: string; issues?: string[] } | null;

export default function Dashboard() {
  const [rows, setRows] = useState<Row[] | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [health, setHealth] = useState<Health | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<Notice>(null);
  const [f, setF] = useState({ name: '', description: '', audience: '', tone: 'chaleureux', language: 'fr', contactEmail: '' });
  const file = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setLoadError(null);
    const [list, h] = await Promise.all([api<Row[]>('/api/projects'), api<Health>('/api/health')]);
    if (list.ok) setRows(list.data); else { setRows(null); setLoadError(list.error); }
    if (h.ok) setHealth(h.data);
  }, []);
  useEffect(() => { load(); }, [load]);

  async function create(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setNotice(null);
    const r = await api<{ project: { id: string }; mode: string; note: string }>('/api/projects', jsonInit('POST', { brief: f }));
    setBusy(false);
    if (r.ok) { window.location.href = `/p/${r.data.project.id}`; return; }
    setNotice({ kind: 'bad', text: r.issues?.length ? 'Corrigez les champs suivants :' : r.error, issues: r.issues });
  }

  async function importFile(x: File | undefined) {
    if (!x) return;
    setBusy(true); setNotice(null);
    let payload: unknown;
    try { payload = JSON.parse(await x.text()); } catch { setBusy(false); setNotice({ kind: 'bad', text: 'Ce fichier n’est pas un JSON valide.' }); return; }
    const r = await api('/api/projects/import', jsonInit('POST', payload));
    setBusy(false);
    if (file.current) file.current.value = '';
    if (r.ok) { setNotice({ kind: 'ok', text: 'Site importé.' }); load(); }
    else setNotice({ kind: 'bad', text: `Import impossible : ${r.error}`, issues: r.issues });
  }

  async function sample() {
    setBusy(true);
    const r = await api('/api/samples', jsonInit('POST'));
    setBusy(false);
    if (r.ok) { setNotice({ kind: 'ok', text: 'Exemple fictif ajouté (étiqueté « EXEMPLE »).' }); load(); } else setNotice({ kind: 'bad', text: r.error });
  }

  async function removeSamples() {
    const r = await api<{ deleted: number }>('/api/samples', jsonInit('DELETE'));
    if (r.ok) { setNotice({ kind: 'ok', text: `${r.data.deleted} exemple(s) supprimé(s).` }); load(); } else setNotice({ kind: 'bad', text: r.error });
  }

  async function remove(p: Row) {
    if (!confirm(`Supprimer « ${p.name} » ? Pensez à l’exporter avant (fichier JSON).`)) return;
    const r = await api(`/api/projects/${p.id}`, jsonInit('DELETE'));
    if (r.ok) { setNotice({ kind: 'ok', text: 'Site supprimé.' }); load(); } else setNotice({ kind: 'bad', text: r.error });
  }

  const set = (k: keyof typeof f) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });

  return (
    <main className="wrap">
      <h1>HexSite</h1>
      <p className="muted">Décrivez votre activité, obtenez un site en sections modifiables, prévisualisez-le sur ordinateur, tablette et mobile, puis publiez des fichiers statiques. Privé et local : aucune donnée n’est envoyée nulle part, sauf à l’IA si vous en configurez une.</p>

      <div className="panel" aria-live="polite">
        {health === null ? <span className="chip">Vérification de l’IA…</span>
          : health.ai.configured ? <span className="chip ok">IA configurée ({health.ai.model}) : votre description et le texte des sections concernées sont envoyés à api.anthropic.com</span>
          : <span className="chip warn">Mode sans IA</span>}
        {health && !health.ai.configured && (
          <details><summary>Qu’est-ce que le mode sans IA ?</summary>
            <p className="muted">Aucune clé <code>ANTHROPIC_API_KEY</code> dans <code>.env</code> : un générateur à règles simples découpe votre description en sections, sans rien inventer (ce qui manque est marqué « À compléter »). La réécriture par IA est désactivée. Tout le reste fonctionne.</p>
          </details>)}
      </div>

      {notice && (
        <div className={`alert ${notice.kind}`} role={notice.kind === 'bad' ? 'alert' : 'status'}>
          {notice.text}
          {notice.issues && <ul>{notice.issues.map((i) => <li key={i}>{i}</li>)}</ul>}
        </div>)}

      <section className="panel" aria-labelledby="new">
        <h2 id="new">Nouveau site</h2>
        <form onSubmit={create} noValidate>
          <label htmlFor="name">Nom de l’activité *</label>
          <input id="name" value={f.name} onChange={set('name')} maxLength={80} required />
          <label htmlFor="desc">Description *</label>
          <textarea id="desc" value={f.description} onChange={set('description')} maxLength={1200} required aria-describedby="desc-help" />
          <p id="desc-help" className="muted">Quelques phrases : ce que vous faites, pour qui. Seuls les faits que vous écrivez ici apparaîtront sur le site.</p>
          <label htmlFor="aud">Public visé</label>
          <input id="aud" value={f.audience} onChange={set('audience')} maxLength={300} />
          <div className="row">
            <div className="grow"><label htmlFor="tone">Ton</label>
              <select id="tone" value={f.tone} onChange={set('tone')}><option value="chaleureux">Chaleureux</option><option value="professionnel">Professionnel</option><option value="direct">Direct</option></select></div>
            <div className="grow"><label htmlFor="lang">Langue du site</label>
              <select id="lang" value={f.language} onChange={set('language')}><option value="fr">Français</option><option value="en">English</option></select></div>
            <div className="grow"><label htmlFor="mail">E-mail de contact (optionnel)</label>
              <input id="mail" type="email" value={f.contactEmail} onChange={set('contactEmail')} maxLength={120} /></div>
          </div>
          <p><button className="primary" disabled={busy}>{busy ? 'Génération en cours…' : 'Générer le site'}</button></p>
        </form>
      </section>

      <section className="panel" aria-labelledby="mine">
        <div className="row"><h2 id="mine" className="grow">Mes sites</h2>
          <label className="btn" htmlFor="imp" style={{ margin: 0, fontWeight: 400 }}>Importer un export JSON</label>
          <input id="imp" ref={file} type="file" accept="application/json,.json" style={{ position: 'absolute', left: -9999 }} onChange={(e) => importFile(e.target.files?.[0])} />
          {rows?.some((r) => r.isSample) && <button onClick={removeSamples}>Supprimer les exemples</button>}
        </div>
        {rows === null && !loadError && <p className="skeleton" role="status">Chargement…</p>}
        {loadError && <div className="alert bad" role="alert">{loadError} <button onClick={load}>Réessayer</button></div>}
        {rows?.length === 0 && (
          <div className="alert info"><strong>Aucun site pour l’instant.</strong> Remplissez le formulaire ci-dessus, importez un export, ou <button onClick={sample} disabled={busy}>chargez un exemple fictif</button> (supprimable en un clic).</div>)}
        {rows && rows.length > 0 && (
          <ul className="list">{rows.map((p) => (
            <li key={p.id}>
              <span className="grow"><Link href={`/p/${p.id}`}><strong>{p.name}</strong></Link>{p.isSample && <span className="badge">EXEMPLE</span>}
                <br /><span className="muted">{p.sections} sections · modifié le {new Date(p.updatedAt).toLocaleString('fr-FR', { dateStyle: 'medium', timeStyle: 'short' })}</span></span>
              <Link className="btn" href={`/p/${p.id}`}>Ouvrir</Link>
              <a className="btn" href={`/api/projects/${p.id}/export`} download>Exporter</a>
              <button className="danger" onClick={() => remove(p)}>Supprimer</button>
            </li>))}</ul>)}
      </section>
    </main>
  );
}
