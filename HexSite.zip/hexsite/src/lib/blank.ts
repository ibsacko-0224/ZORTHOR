import type { Section, SectionKind } from './types';
import { newId } from './validate';

/** Section vide à compléter (ajout manuel depuis l'éditeur). */
export function blankSection(kind: SectionKind): Section {
  const id = newId();
  switch (kind) {
    case 'hero': return { id, kind, eyebrow: '', title: 'Titre principal', subtitle: 'À compléter', ctaLabel: 'Nous contacter', ctaHref: '#contact' };
    case 'features': return { id, kind, title: 'Points forts', intro: '', items: [{ title: 'Point fort', text: 'À compléter' }] };
    case 'about': return { id, kind, title: 'À propos', body: 'À compléter' };
    case 'faq': return { id, kind, title: 'Questions fréquentes', items: [{ q: 'Question ?', a: 'Réponse à compléter' }] };
    case 'cta': return { id, kind, title: 'Parlons-en', text: '', buttonLabel: 'Nous contacter', buttonHref: '#contact' };
    case 'footer': return { id, kind, brand: 'Nom du site', text: '', links: [] };
  }
}
