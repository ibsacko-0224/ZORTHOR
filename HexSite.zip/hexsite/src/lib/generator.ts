import { aiGenerate, AiError, type FetchLike } from './ai';
import type { AiConfig } from './env';
import type { Brief, Doc, Section, Theme } from './types';
import { newId } from './validate';

export const DEFAULT_THEME: Theme = { palette: 'bleu', font: 'sans', mode: 'light' };

const T = {
  fr: {
    contact: 'Nous contacter', contactTitle: 'Parlons de votre projet', contactText: 'Écrivez-nous : nous vous répondons dès que possible.',
    about: 'À propos', features: 'Ce que nous faisons', featuresIntro: 'L’essentiel, en quelques points.', faq: 'Questions fréquentes',
    q1: 'Pour qui est-ce ?', q2: 'Comment vous contacter ?', a2: 'Utilisez le bouton « Nous contacter » de cette page.', q3: 'Comment démarrer ?', a3: 'Écrivez-nous en décrivant votre besoin, nous reviendrons vers vous.',
    point: 'Point fort', todo: 'À compléter : décrivez ici un bénéfice concret pour vos visiteurs.', rights: 'Tous droits réservés.', top: 'Haut de page',
  },
  en: {
    contact: 'Contact us', contactTitle: 'Let’s talk about your project', contactText: 'Write to us: we reply as soon as we can.',
    about: 'About', features: 'What we do', featuresIntro: 'The essentials, in a few points.', faq: 'Frequently asked questions',
    q1: 'Who is it for?', q2: 'How can I get in touch?', a2: 'Use the “Contact us” button on this page.', q3: 'How do I get started?', a3: 'Write to us describing your need and we will get back to you.',
    point: 'Key point', todo: 'To complete: describe a concrete benefit for your visitors here.', rights: 'All rights reserved.', top: 'Back to top',
  },
} as const;

const cut = (s: string, n: number) => (s.length <= n ? s : s.slice(0, n - 1).replace(/\s+\S*$/, '') + '…');

function sentences(text: string): string[] {
  return text.split(/(?<=[.!?])\s+|\n+/).map((s) => s.trim()).filter(Boolean);
}

/**
 * MODE SANS IA : règles simples et déterministes. Aucune information n'est inventée : le texte vient de votre description,
 * découpée en phrases ; ce qui manque est marqué « À compléter ». Ce n'est pas de la rédaction intelligente.
 */
export function ruleBasedDoc(brief: Brief, theme: Theme = DEFAULT_THEME, now = new Date()): Doc {
  const t = T[brief.language];
  const parts = sentences(brief.description);
  const lead = parts[0] ?? brief.description;
  const rest = parts.slice(1);
  const mail = brief.contactEmail ? `mailto:${brief.contactEmail}` : '#contact';

  const items = (rest.length ? rest : [lead]).slice(0, 3).map((s, i) => ({ title: `${t.point} ${i + 1}`, text: cut(s, 280) }));
  while (items.length < 3) items.push({ title: `${t.point} ${items.length + 1}`, text: t.todo });

  const sections: Section[] = [
    { id: newId(), kind: 'hero', eyebrow: '', title: cut(brief.name, 120), subtitle: cut(lead, 300), ctaLabel: t.contact, ctaHref: mail },
    { id: newId(), kind: 'features', title: t.features, intro: t.featuresIntro, items },
    { id: newId(), kind: 'about', title: t.about, body: brief.description },
    { id: newId(), kind: 'faq', title: t.faq, items: [
      { q: t.q1, a: brief.audience || t.todo }, { q: t.q2, a: t.a2 }, { q: t.q3, a: t.a3 },
    ] },
    { id: newId(), kind: 'cta', title: t.contactTitle, text: t.contactText, buttonLabel: t.contact, buttonHref: mail },
    { id: newId(), kind: 'footer', brand: brief.name, text: `© ${now.getFullYear()} ${brief.name}. ${t.rights}`, links: [{ label: t.top, href: '#top' }] },
  ];
  return { brief, theme, seo: { title: cut(brief.name, 70), description: cut(lead, 160) }, sections };
}

export type Generated = { doc: Doc; mode: 'ai' | 'degraded'; note: string };

/** Avec une clé : IA. Sinon, ou si l'IA échoue : mode sans IA, avec une note claire. */
export async function generateDoc(brief: Brief, opts: { ai: AiConfig | null; theme?: Theme; fetchFn?: FetchLike }): Promise<Generated> {
  const theme = opts.theme ?? DEFAULT_THEME;
  if (!opts.ai) {
    return { doc: ruleBasedDoc(brief, theme), mode: 'degraded', note: 'Généré sans IA (règles simples, aucune clé configurée) : relisez et complétez les textes.' };
  }
  try {
    return { doc: await aiGenerate(opts.ai, brief, { theme }, opts.fetchFn), mode: 'ai', note: 'Généré par IA : relisez, l’IA peut se tromper.' };
  } catch (e) {
    const why = e instanceof AiError ? e.message : 'erreur inattendue';
    return { doc: ruleBasedDoc(brief, theme), mode: 'degraded', note: `L’IA a échoué (${why}) : site généré sans IA, relisez et complétez les textes.` };
  }
}
