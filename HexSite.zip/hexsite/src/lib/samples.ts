import { ruleBasedDoc } from './generator';
import type { Doc } from './types';

/** Données d'exemple FICTIVES, clairement étiquetées : le nom commence par « [EXEMPLE] » ; supprimables en un clic. */
export const SAMPLE_NAME = '[EXEMPLE] Atelier Le Fournil';

export function sampleDoc(): Doc {
  const doc = ruleBasedDoc({
    name: 'Atelier Le Fournil',
    description: 'Boulangerie artisanale de quartier, fictive et donnée à titre d’exemple. Pain au levain cuit chaque matin au feu de bois. Viennoiseries maison préparées avec du beurre de baratte. Commandes pour les fêtes et les événements sur demande.',
    audience: 'Habitants du quartier et professionnels de la restauration qui veulent du pain de qualité.',
    tone: 'chaleureux', language: 'fr', contactEmail: 'contact@exemple.invalid',
  }, { palette: 'ambre', font: 'serif', mode: 'light' });
  doc.seo = { title: '[Exemple] Atelier Le Fournil', description: 'Site d’exemple fictif généré par HexSite.' };
  return doc;
}
