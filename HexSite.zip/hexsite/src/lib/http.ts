import { logError } from './log';
import { ValidationError } from './validate';

export class AppError extends Error {
  constructor(public status: number, public code: string, message: string) { super(message); }
}

export function json(data: unknown, status = 200): Response {
  return Response.json(data, { status, headers: { 'cache-control': 'no-store' } });
}

/** Transforme toute erreur en réponse JSON propre. Aucune stack, aucun détail interne. */
export function handle<A extends unknown[]>(fn: (...a: A) => Promise<Response> | Response) {
  return async (...a: A): Promise<Response> => {
    try {
      return await fn(...a);
    } catch (e) {
      if (e instanceof AppError) return json({ error: { code: e.code, message: e.message } }, e.status);
      if (e instanceof ValidationError) return json({ error: { code: 'invalid', message: e.message, issues: e.issues } }, 400);
      logError('route', e);
      return json({ error: { code: 'internal', message: 'Erreur interne du serveur local. Consultez le terminal.' } }, 500);
    }
  };
}

export async function readJson(req: Request, maxBytes = 2_000_000): Promise<unknown> {
  if (Number(req.headers.get('content-length') ?? 0) > maxBytes) throw new AppError(413, 'too_large', 'Requête trop volumineuse.');
  const text = await req.text();
  if (text.length > maxBytes) throw new AppError(413, 'too_large', 'Requête trop volumineuse.');
  try { return text ? JSON.parse(text) : {}; } catch { throw new AppError(400, 'bad_json', 'JSON invalide.'); }
}
