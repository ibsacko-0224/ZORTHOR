/** Journal minimal : jamais de secret, jamais de contenu de site ni de fichier. Seulement la portée et le type d'erreur. */
export function logError(scope: string, err: unknown): void {
  const kind = err instanceof Error ? err.constructor.name : typeof err;
  console.error(`[hexsite] ${scope} : ${kind}`);
}
