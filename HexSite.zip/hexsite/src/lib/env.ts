import path from 'node:path';

export const dataDir = () => path.resolve(process.env.DATA_DIR || './data');
export const publishDir = () => path.resolve(process.env.PUBLISH_DIR || './exports');

export type AiConfig = { apiKey: string; model: string };

/** null = pas de clé : l'application fonctionne en « mode sans IA ». La clé n'est jamais journalisée ni renvoyée au navigateur. */
export function aiConfig(): AiConfig | null {
  const apiKey = (process.env.ANTHROPIC_API_KEY || '').trim();
  if (!apiKey) return null;
  return { apiKey, model: (process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5').trim() };
}
