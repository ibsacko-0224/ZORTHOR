export const SECTION_KINDS = ['hero', 'features', 'about', 'faq', 'cta', 'footer'] as const;
export type SectionKind = (typeof SECTION_KINDS)[number];

export const KIND_LABELS: Record<SectionKind, string> = {
  hero: 'En-tête', features: 'Points forts', about: 'À propos', faq: 'Questions fréquentes', cta: 'Appel à l’action', footer: 'Pied de page',
};

export type LinkItem = { label: string; href: string };

export type Section =
  | { id: string; kind: 'hero'; eyebrow: string; title: string; subtitle: string; ctaLabel: string; ctaHref: string }
  | { id: string; kind: 'features'; title: string; intro: string; items: { title: string; text: string }[] }
  | { id: string; kind: 'about'; title: string; body: string }
  | { id: string; kind: 'faq'; title: string; items: { q: string; a: string }[] }
  | { id: string; kind: 'cta'; title: string; text: string; buttonLabel: string; buttonHref: string }
  | { id: string; kind: 'footer'; brand: string; text: string; links: LinkItem[] };

export const PALETTES = ['bleu', 'emeraude', 'rouge', 'violet', 'ambre', 'ardoise'] as const;
export const TONES = ['chaleureux', 'professionnel', 'direct'] as const;

export type Theme = { palette: (typeof PALETTES)[number]; font: 'sans' | 'serif'; mode: 'light' | 'dark' };
export type Brief = {
  name: string; description: string; audience: string;
  tone: (typeof TONES)[number]; language: 'fr' | 'en'; contactEmail: string;
};
export type Doc = {
  brief: Brief; theme: Theme; seo: { title: string; description: string }; sections: Section[];
};
export type Project = Doc & { id: string; slug: string; name: string; isSample: boolean; createdAt: number; updatedAt: number };

export const LIMITS = {
  name: 80, description: 1200, audience: 300, title: 160, text: 600, body: 3000, label: 60, href: 500,
  items: 12, sections: 30, linkItems: 12, importBytes: 2_000_000,
} as const;
