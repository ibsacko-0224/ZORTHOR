import fs from 'node:fs';
import path from 'node:path';
import { publishDir } from './env';
import { AppError } from './http';
import { renderFiles } from './render';
import { recordPublish, requireProject } from './store';
import { createZip } from './zip';

export type PublishResult = { dir: string; files: string[]; bytes: number; at: number };

/** Écrit le site statique dans PUBLISH_DIR/<slug>/. Le dossier cible est vérifié : on n'écrit jamais en dehors de PUBLISH_DIR. */
export function publishProject(id: string): PublishResult {
  const p = requireProject(id);
  const files = renderFiles(p, p.name);
  const root = publishDir();
  const target = path.resolve(root, p.slug);
  if (!/^[a-z0-9-]+$/.test(p.slug) || path.dirname(target) !== root) throw new AppError(400, 'bad_slug', 'Nom de dossier refusé.');
  try {
    fs.mkdirSync(root, { recursive: true });
    fs.rmSync(target, { recursive: true, force: true });
    fs.mkdirSync(target, { recursive: true });
    let bytes = 0;
    for (const [name, content] of Object.entries(files)) {
      fs.writeFileSync(path.join(target, name), content, 'utf8');
      bytes += Buffer.byteLength(content);
    }
    recordPublish(p.id, target, Object.keys(files).length, bytes);
    return { dir: target, files: Object.keys(files), bytes, at: Date.now() };
  } catch (e) {
    if (e instanceof AppError) throw e;
    throw new AppError(500, 'publish_failed', 'Écriture impossible dans le dossier de publication : vérifiez PUBLISH_DIR et les droits d’écriture.');
  }
}

export function zipProject(id: string): { name: string; data: Buffer } {
  const p = requireProject(id);
  return { name: `${p.slug}.zip`, data: createZip(renderFiles(p, p.name)) };
}
