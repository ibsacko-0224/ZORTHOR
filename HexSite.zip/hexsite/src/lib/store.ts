import fs from 'node:fs';
import path from 'node:path';
import type { DatabaseSync } from 'node:sqlite';
import { dataDir } from './env';
import { AppError } from './http';
import type { Doc, Project } from './types';
import { isValidId, newId, slugify, validateDoc, validateName } from './validate';

// SQLite fourni par Node (≥ 22.13) : aucune dépendance native. process.getBuiltinModule évite que le bundler tente de le résoudre.
type SqliteModule = typeof import('node:sqlite');
const sqlite = (process as unknown as { getBuiltinModule: (id: string) => unknown }).getBuiltinModule('node:sqlite') as SqliteModule;

const DDL = `
CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  data TEXT NOT NULL,
  is_sample INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS publishes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  at INTEGER NOT NULL,
  dir TEXT NOT NULL,
  files INTEGER NOT NULL,
  bytes INTEGER NOT NULL
);
`;

const g = globalThis as unknown as { __hexsiteDb?: { dir: string; db: DatabaseSync } };

export function getDb(): DatabaseSync {
  const dir = dataDir();
  if (g.__hexsiteDb?.dir === dir) return g.__hexsiteDb.db;
  g.__hexsiteDb?.db.close();
  fs.mkdirSync(dir, { recursive: true });
  const db = new sqlite.DatabaseSync(path.join(dir, 'hexsite.db'));
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
  db.exec(DDL);
  g.__hexsiteDb = { dir, db };
  return db;
}

type Row = { id: string; slug: string; name: string; data: string; is_sample: number; created_at: number; updated_at: number };

function fromRow(r: Row): Project {
  const doc = JSON.parse(r.data) as Doc;
  return { ...doc, id: r.id, slug: r.slug, name: r.name, isSample: r.is_sample === 1, createdAt: r.created_at, updatedAt: r.updated_at };
}

export type ProjectSummary = { id: string; slug: string; name: string; isSample: boolean; sections: number; updatedAt: number };

export function listProjects(): ProjectSummary[] {
  const rows = getDb().prepare('SELECT * FROM projects ORDER BY updated_at DESC').all() as unknown as Row[];
  return rows.map((r) => ({ id: r.id, slug: r.slug, name: r.name, isSample: r.is_sample === 1, sections: (JSON.parse(r.data) as Doc).sections.length, updatedAt: r.updated_at }));
}

export function assertId(id: string): void {
  if (!isValidId(id)) throw new AppError(400, 'bad_id', 'Identifiant invalide.');
}

export function getProject(id: string): Project | null {
  assertId(id);
  const r = getDb().prepare('SELECT * FROM projects WHERE id = ?').get(id) as unknown as Row | undefined;
  return r ? fromRow(r) : null;
}

export function requireProject(id: string): Project {
  const p = getProject(id);
  if (!p) throw new AppError(404, 'not_found', 'Site introuvable.');
  return p;
}

function uniqueSlug(name: string): string {
  const db = getDb();
  const base = slugify(name);
  let slug = base;
  for (let i = 2; db.prepare('SELECT 1 FROM projects WHERE slug = ?').get(slug); i++) slug = `${base}-${i}`;
  return slug;
}

export function createProject(name: unknown, doc: unknown, isSample = false): Project {
  const n = validateName(name);
  const d = validateDoc(doc);
  const id = newId(12);
  const now = Date.now();
  getDb().prepare('INSERT INTO projects (id, slug, name, data, is_sample, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(id, uniqueSlug(n), n, JSON.stringify(d), isSample ? 1 : 0, now, now);
  return requireProject(id);
}

export function updateProject(id: string, input: { name?: unknown; doc: unknown }): Project {
  const cur = requireProject(id);
  const d = validateDoc(input.doc);
  const n = input.name === undefined ? cur.name : validateName(input.name);
  getDb().prepare('UPDATE projects SET name = ?, data = ?, updated_at = ? WHERE id = ?').run(n, JSON.stringify(d), Date.now(), id);
  return requireProject(id);
}

export function deleteProject(id: string): void {
  requireProject(id);
  getDb().prepare('DELETE FROM projects WHERE id = ?').run(id);
}

export function deleteSamples(): number {
  const r = getDb().prepare('DELETE FROM projects WHERE is_sample = 1').run();
  return Number(r.changes);
}

export function recordPublish(projectId: string, dir: string, files: number, bytes: number): void {
  getDb().prepare('INSERT INTO publishes (project_id, at, dir, files, bytes) VALUES (?, ?, ?, ?, ?)').run(projectId, Date.now(), dir, files, bytes);
}

export function lastPublish(projectId: string): { at: number; dir: string; files: number; bytes: number } | null {
  const r = getDb().prepare('SELECT at, dir, files, bytes FROM publishes WHERE project_id = ? ORDER BY id DESC LIMIT 1').get(projectId) as unknown as { at: number; dir: string; files: number; bytes: number } | undefined;
  return r ? { at: Number(r.at), dir: r.dir, files: Number(r.files), bytes: Number(r.bytes) } : null;
}
