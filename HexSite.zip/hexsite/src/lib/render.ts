// Rendu 100 % pur (aucun module Node) : le MÊME code produit l'aperçu dans le navigateur et les fichiers publiés.
import type { Doc, Section, Theme } from './types';
import { isSafeHref } from './validate';

const PALETTE = {
  bleu: { accent: '#1D4ED8', soft: '#93C5FD' }, emeraude: { accent: '#047857', soft: '#6EE7B7' },
  rouge: { accent: '#B91C1C', soft: '#FCA5A5' }, violet: { accent: '#6D28D9', soft: '#C4B5FD' },
  ambre: { accent: '#B45309', soft: '#FCD34D' }, ardoise: { accent: '#334155', soft: '#CBD5E1' },
} as const;

export const esc = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');

const href = (h: string) => (h && isSafeHref(h) ? esc(h) : '#');

function paragraphs(text: string): string {
  return text.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean).map((p) => `<p>${esc(p).replace(/\n/g, '<br>')}</p>`).join('\n');
}

export function css(theme: Theme): string {
  const c = PALETTE[theme.palette];
  const dark = theme.mode === 'dark';
  const font = theme.font === 'serif' ? 'Georgia, "Iowan Old Style", "Times New Roman", serif' : 'system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif';
  return `:root{--bg:${dark ? '#0B1020' : '#FFFFFF'};--fg:${dark ? '#E8ECF5' : '#111827'};--muted:${dark ? '#A9B4C8' : '#4B5563'};--surface:${dark ? '#121A2E' : '#F3F4F6'};--border:${dark ? '#2A3550' : '#D1D5DB'};--accent:${c.accent};--link:${dark ? c.soft : c.accent};--font:${font};--radius:.75rem}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--fg);font-family:var(--font);line-height:1.6;font-size:1.0625rem}
.wrap{max-width:68rem;margin:0 auto;padding:0 1.25rem}
.skip{position:absolute;left:-999px;top:0;background:var(--fg);color:var(--bg);padding:.6rem 1rem;z-index:10}.skip:focus{left:1rem;top:1rem}
.bar{border-bottom:1px solid var(--border)}.bar .wrap{display:flex;align-items:center;justify-content:space-between;padding-top:1rem;padding-bottom:1rem}
.brand{font-weight:700;color:var(--fg);text-decoration:none;font-size:1.125rem}
section{padding:4.5rem 0}section+section{border-top:1px solid var(--border)}.hero{padding:6rem 0}
h1,h2,h3{line-height:1.15;margin:0 0 .75rem;overflow-wrap:anywhere}
h1{font-size:clamp(2rem,6vw,3.5rem)}h2{font-size:clamp(1.5rem,4vw,2.25rem)}h3{font-size:1.2rem}
p{margin:0 0 1rem;overflow-wrap:anywhere}.lead{font-size:1.2rem;color:var(--muted);max-width:42rem}
.eyebrow{color:var(--link);font-weight:600;margin:0 0 .75rem}
.btn{display:inline-block;background:var(--accent);color:#fff;padding:.8rem 1.4rem;border-radius:var(--radius);text-decoration:none;font-weight:600}.btn:hover{filter:brightness(1.12)}
a{color:var(--link)}a:focus-visible,summary:focus-visible{outline:3px solid var(--link);outline-offset:3px}
.btn:focus-visible{outline:3px solid var(--fg);outline-offset:3px}
.grid{display:grid;gap:1.25rem;grid-template-columns:repeat(auto-fit,minmax(15rem,1fr))}
.card{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:1.4rem}.card p{margin:0}
details{border-top:1px solid var(--border);padding:1rem 0}details:last-of-type{border-bottom:1px solid var(--border)}summary{cursor:pointer;font-weight:600}details p{margin:.75rem 0 0;color:var(--muted)}
.cta{background:var(--surface)}
footer{border-top:1px solid var(--border);padding:2.5rem 0;color:var(--muted)}footer p{margin:0}footer ul{list-style:none;padding:0;display:flex;flex-wrap:wrap;gap:1rem 1.5rem;margin:1rem 0 0}
.narrow{max-width:46rem}
@media (max-width:640px){section{padding:3rem 0}.hero{padding:3.5rem 0}.bar .wrap{flex-direction:column;align-items:flex-start;gap:.5rem}}
@media (prefers-reduced-motion:reduce){html{scroll-behavior:auto}}
`;
}

function section(s: Section, firstOfKind: boolean): string {
  const id = firstOfKind && s.kind !== 'hero' ? ` id="${s.kind === 'cta' ? 'contact' : s.kind}"` : '';
  switch (s.kind) {
    case 'hero':
      return `<section class="hero"><div class="wrap">${s.eyebrow ? `<p class="eyebrow">${esc(s.eyebrow)}</p>` : ''}<h1>${esc(s.title)}</h1>${s.subtitle ? `<p class="lead">${esc(s.subtitle)}</p>` : ''}${s.ctaLabel ? `<p><a class="btn" href="${href(s.ctaHref)}">${esc(s.ctaLabel)}</a></p>` : ''}</div></section>`;
    case 'features':
      return `<section${id}><div class="wrap"><h2>${esc(s.title)}</h2>${s.intro ? `<p class="lead">${esc(s.intro)}</p>` : ''}<div class="grid">${s.items.map((i) => `<article class="card"><h3>${esc(i.title)}</h3>${i.text ? `<p>${esc(i.text)}</p>` : ''}</article>`).join('')}</div></div></section>`;
    case 'about':
      return `<section${id}><div class="wrap narrow"><h2>${esc(s.title)}</h2>${paragraphs(s.body)}</div></section>`;
    case 'faq':
      return `<section${id}><div class="wrap narrow"><h2>${esc(s.title)}</h2>${s.items.map((i) => `<details><summary>${esc(i.q)}</summary><p>${esc(i.a)}</p></details>`).join('')}</div></section>`;
    case 'cta':
      return `<section class="cta"${id}><div class="wrap narrow"><h2>${esc(s.title)}</h2>${s.text ? `<p class="lead">${esc(s.text)}</p>` : ''}${s.buttonLabel ? `<p><a class="btn" href="${href(s.buttonHref)}">${esc(s.buttonLabel)}</a></p>` : ''}</div></section>`;
    case 'footer':
      return `<footer><div class="wrap"><p><strong>${esc(s.brand)}</strong></p>${s.text ? `<p>${esc(s.text)}</p>` : ''}${s.links.length ? `<nav aria-label="Liens du pied de page"><ul>${s.links.map((l) => `<li><a href="${href(l.href)}">${esc(l.label)}</a></li>`).join('')}</ul></nav>` : ''}</div></footer>`;
  }
}

/** Fichiers du site statique : index.html, style.css, robots.txt. Aucune ressource externe, aucun script, aucun traceur. */
export function renderFiles(doc: Doc, name: string): Record<string, string> {
  const seen = new Set<string>();
  const body = doc.sections.filter((s) => s.kind !== 'footer').map((s) => { const first = !seen.has(s.kind); seen.add(s.kind); return section(s, first); }).join('\n');
  const foot = doc.sections.filter((s) => s.kind === 'footer').map((s) => section(s, true)).join('\n');
  const html = `<!doctype html>
<html lang="${doc.brief.language}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(doc.seo.title || name)}</title>
<meta name="description" content="${esc(doc.seo.description)}">
<link rel="stylesheet" href="style.css">
</head>
<body id="top">
<a class="skip" href="#main">${doc.brief.language === 'fr' ? 'Aller au contenu' : 'Skip to content'}</a>
<header class="bar"><div class="wrap"><a class="brand" href="#top">${esc(name)}</a></div></header>
<main id="main">
${body}
</main>
${foot}
</body>
</html>
`;
  return { 'index.html': html, 'style.css': css(doc.theme), 'robots.txt': 'User-agent: *\nAllow: /\n' };
}

/** Aperçu autonome (CSS intégré) pour un iframe sandboxé : les liens ne remplacent jamais l'aperçu. */
export function previewHtml(doc: Doc, name: string): string {
  const f = renderFiles(doc, name);
  return f['index.html'].replace('<link rel="stylesheet" href="style.css">', `<base target="_blank"><style>${f['style.css']}</style>`);
}
