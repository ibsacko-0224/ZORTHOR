import { LIMITS, PALETTES, SECTION_KINDS, TONES, type Brief, type Doc, type Section, type Theme } from './types';

export class ValidationError extends Error {
  constructor(public issues: string[]) {
    super(issues.slice(0, 3).join(' ; '));
  }
}

const ID_RE = /^[a-z0-9]{6,24}$/;
const HREF_RE = /^(?:https?:\/\/[^\s<>"']+|mailto:[^\s@<>]+@[^\s@<>]+|tel:[+\d\s().-]{3,30}|#[\w-]*|\/(?!\/)[^\s<>"']*)$/i;
// eslint-disable-next-line no-control-regex
const CONTROL = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g;

export const isSafeHref = (v: string) => v === '' || HREF_RE.test(v);
export const isValidId = (v: string) => ID_RE.test(v);

export function newId(len = 10): string {
  const alphabet = 'abcdefghijklmnopqrstuvwxyz0123456789';
  const bytes = new Uint8Array(len);
  globalThis.crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join('');
}

export function slugify(input: string, max = 50): string {
  const s = input.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, max).replace(/-+$/, '');
  return s || 'site';
}

// ───────── helpers de validation (collectent toutes les erreurs au lieu de s'arrêter à la première)
type Issues = string[];

function str(v: unknown, path: string, max: number, issues: Issues, required = false): string {
  if (typeof v !== 'string') {
    if (required || v !== undefined) issues.push(`${path} : texte attendu`);
    return '';
  }
  const t = v.replace(/\r\n/g, '\n').replace(CONTROL, '').trim();
  if (required && !t) issues.push(`${path} : champ requis`);
  if (t.length > max) { issues.push(`${path} : ${max} caractères maximum`); return t.slice(0, max); }
  return t;
}

function link(v: unknown, path: string, issues: Issues): string {
  const t = str(v, path, LIMITS.href, issues);
  if (t && !isSafeHref(t)) issues.push(`${path} : lien invalide (https, mailto, tel, #ancre ou /chemin)`);
  return t;
}

function arr(v: unknown, path: string, max: number, issues: Issues): unknown[] {
  if (v === undefined) return [];
  if (!Array.isArray(v)) { issues.push(`${path} : liste attendue`); return []; }
  if (v.length > max) { issues.push(`${path} : ${max} éléments maximum`); return v.slice(0, max); }
  return v;
}

function obj(v: unknown, path: string, issues: Issues): Record<string, unknown> {
  if (typeof v !== 'object' || v === null || Array.isArray(v)) { issues.push(`${path} : objet attendu`); return {}; }
  return v as Record<string, unknown>;
}

export function validateBrief(raw: unknown, path = 'brief', issues: Issues = []): Brief {
  const o = obj(raw, path, issues);
  const tone = o.tone ?? 'chaleureux';
  if (!(TONES as readonly string[]).includes(tone as string)) issues.push(`${path}.tone : valeur inconnue`);
  const lang = o.language ?? 'fr';
  if (lang !== 'fr' && lang !== 'en') issues.push(`${path}.language : « fr » ou « en »`);
  const email = str(o.contactEmail, `${path}.contactEmail`, 120, issues);
  if (email && !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(email)) issues.push(`${path}.contactEmail : adresse invalide`);
  return {
    name: str(o.name, `${path}.name`, LIMITS.name, issues, true),
    description: str(o.description, `${path}.description`, LIMITS.description, issues, true),
    audience: str(o.audience, `${path}.audience`, LIMITS.audience, issues),
    tone: (TONES as readonly string[]).includes(tone as string) ? (tone as Brief['tone']) : 'chaleureux',
    language: lang === 'en' ? 'en' : 'fr',
    contactEmail: email,
  };
}

export function parseBrief(raw: unknown): Brief {
  const issues: Issues = [];
  const b = validateBrief(raw, 'brief', issues);
  if (issues.length) throw new ValidationError(issues);
  return b;
}

function validateTheme(raw: unknown, issues: Issues): Theme {
  const o = obj(raw ?? {}, 'theme', issues);
  const palette = o.palette ?? 'bleu';
  if (!(PALETTES as readonly string[]).includes(palette as string)) issues.push('theme.palette : valeur inconnue');
  const font = o.font ?? 'sans';
  if (font !== 'sans' && font !== 'serif') issues.push('theme.font : « sans » ou « serif »');
  const mode = o.mode ?? 'light';
  if (mode !== 'light' && mode !== 'dark') issues.push('theme.mode : « light » ou « dark »');
  return {
    palette: (PALETTES as readonly string[]).includes(palette as string) ? (palette as Theme['palette']) : 'bleu',
    font: font === 'serif' ? 'serif' : 'sans',
    mode: mode === 'dark' ? 'dark' : 'light',
  };
}

export function validateSection(raw: unknown, idx: number, issues: Issues): Section | null {
  const path = `sections[${idx}]`;
  const o = obj(raw, path, issues);
  const kind = o.kind;
  if (typeof kind !== 'string' || !(SECTION_KINDS as readonly string[]).includes(kind)) {
    issues.push(`${path}.kind : type de section inconnu`);
    return null;
  }
  let id = typeof o.id === 'string' ? o.id : '';
  if (!id) id = newId();
  else if (!ID_RE.test(id)) { issues.push(`${path}.id : identifiant invalide`); id = newId(); }

  switch (kind) {
    case 'hero':
      return {
        id, kind, eyebrow: str(o.eyebrow, `${path}.eyebrow`, LIMITS.label, issues),
        title: str(o.title, `${path}.title`, LIMITS.title, issues, true), subtitle: str(o.subtitle, `${path}.subtitle`, LIMITS.text, issues),
        ctaLabel: str(o.ctaLabel, `${path}.ctaLabel`, LIMITS.label, issues), ctaHref: link(o.ctaHref, `${path}.ctaHref`, issues),
      };
    case 'features':
      return {
        id, kind, title: str(o.title, `${path}.title`, LIMITS.title, issues, true), intro: str(o.intro, `${path}.intro`, LIMITS.text, issues),
        items: arr(o.items, `${path}.items`, LIMITS.items, issues).map((it, i) => {
          const x = obj(it, `${path}.items[${i}]`, issues);
          return { title: str(x.title, `${path}.items[${i}].title`, LIMITS.title, issues, true), text: str(x.text, `${path}.items[${i}].text`, LIMITS.text, issues) };
        }),
      };
    case 'about':
      return { id, kind, title: str(o.title, `${path}.title`, LIMITS.title, issues, true), body: str(o.body, `${path}.body`, LIMITS.body, issues) };
    case 'faq':
      return {
        id, kind, title: str(o.title, `${path}.title`, LIMITS.title, issues, true),
        items: arr(o.items, `${path}.items`, LIMITS.items, issues).map((it, i) => {
          const x = obj(it, `${path}.items[${i}]`, issues);
          return { q: str(x.q, `${path}.items[${i}].q`, LIMITS.title, issues, true), a: str(x.a, `${path}.items[${i}].a`, LIMITS.body, issues, true) };
        }),
      };
    case 'cta':
      return {
        id, kind, title: str(o.title, `${path}.title`, LIMITS.title, issues, true), text: str(o.text, `${path}.text`, LIMITS.text, issues),
        buttonLabel: str(o.buttonLabel, `${path}.buttonLabel`, LIMITS.label, issues), buttonHref: link(o.buttonHref, `${path}.buttonHref`, issues),
      };
    default:
      return {
        id, kind: 'footer', brand: str(o.brand, `${path}.brand`, LIMITS.name, issues, true), text: str(o.text, `${path}.text`, LIMITS.text, issues),
        links: arr(o.links, `${path}.links`, LIMITS.linkItems, issues).map((it, i) => {
          const x = obj(it, `${path}.links[${i}]`, issues);
          return { label: str(x.label, `${path}.links[${i}].label`, LIMITS.label, issues, true), href: link(x.href, `${path}.links[${i}].href`, issues) };
        }),
      };
  }
}

/** Valide un document complet. Tout texte est nettoyé ; les liens non sûrs (javascript:, data:…) sont refusés. */
export function validateDoc(raw: unknown): Doc {
  const issues: Issues = [];
  const o = obj(raw, 'document', issues);
  const brief = validateBrief(o.brief, 'brief', issues);
  const theme = validateTheme(o.theme, issues);
  const seoRaw = obj(o.seo ?? {}, 'seo', issues);
  const sectionsRaw = arr(o.sections, 'sections', LIMITS.sections, issues);
  if (sectionsRaw.length === 0) issues.push('sections : au moins une section est requise');
  const sections = sectionsRaw.map((s, i) => validateSection(s, i, issues)).filter((s): s is Section => s !== null);
  const seo = {
    title: str(seoRaw.title, 'seo.title', 120, issues) || brief.name,
    description: str(seoRaw.description, 'seo.description', 300, issues) || brief.description.slice(0, 160),
  };
  if (issues.length) throw new ValidationError(issues);
  return { brief, theme, seo, sections };
}

export function validateName(raw: unknown): string {
  const issues: Issues = [];
  const n = str(raw, 'nom', LIMITS.name, issues, true);
  if (issues.length) throw new ValidationError(issues);
  return n;
}

// ───────── import / export portable
export const EXPORT_FORMAT = 'hexsite-project';

export function toExport(p: { name: string } & Doc) {
  return { format: EXPORT_FORMAT, version: 1, exportedAt: new Date().toISOString(), project: { name: p.name, brief: p.brief, theme: p.theme, seo: p.seo, sections: p.sections } };
}

export function parseImport(raw: unknown): { name: string; doc: Doc } {
  const issues: Issues = [];
  const o = obj(raw, 'fichier', issues);
  if (o.format !== EXPORT_FORMAT) throw new ValidationError(['fichier : ce n’est pas un export HexSite']);
  if (o.version !== 1) throw new ValidationError(['fichier : version non prise en charge']);
  const p = obj(o.project, 'project', issues);
  const name = str(p.name, 'project.name', LIMITS.name, issues, true);
  if (issues.length) throw new ValidationError(issues);
  return { name, doc: validateDoc(p) };
}
