# HexSite

Substitut personnel de la boucle principale d'un générateur de sites par IA (type Mixo) : **décrire son activité → obtenir un site en sections structurées → modifier → prévisualiser en responsive → publier des fichiers statiques.**
Un projet **CENTRAL-HEX**. Pile : Next.js 15 · TypeScript · SQLite (celui de Node). Mono-utilisateur, privé, local.

## Installation et lancement
Prérequis : **Node 22.13 ou plus** (SQLite est fourni par Node, aucune dépendance native).

```bash
npm run setup        # crée .env depuis .env.example, installe les dépendances
npm run dev          # développement : http://127.0.0.1:3000
npm test             # tests unitaires + test de fumée de bout en bout
npm run build        # compilation de production
npm run start:local  # compile puis lance en production locale (127.0.0.1:3000)
```
(Si `npm run setup` n'est pas encore possible : `node scripts/setup.mjs`.)

## La boucle principale
1. **Nouveau site** : nom, description, public, ton, langue → sections générées.
2. **Modifier** : en-tête, points forts, à propos, FAQ, appel à l'action, pied de page ; ajouter, retirer, réordonner ; couleur, police, mode clair/sombre ; SEO. Enregistrement automatique.
3. **Aperçu** : ordinateur 1280 px, tablette 820 px, mobile 390 px, avec le code exact qui sera publié.
4. **Publier** : écrit `index.html`, `style.css`, `robots.txt` dans `exports/<site>/` ; téléchargement `.zip` ; export/import JSON.

## IA optionnelle et mode sans IA
- **Sans clé** (défaut) : un générateur à **règles simples** découpe votre description en sections. Il n'invente rien (pas de témoignages, prix, chiffres) ; ce qui manque est marqué « À compléter ». La réécriture d'une section par IA est désactivée, avec une explication dans l'interface. Tout le reste fonctionne.
- **Avec `ANTHROPIC_API_KEY`** dans `.env` : la génération du site et la réécriture d'une section passent par l'API Anthropic (`api.anthropic.com`). **Votre description et le texte des sections concernées sont alors envoyés à ce service.** La réponse est entièrement validée (format, longueurs, liens) avant d'être acceptée ; en cas d'échec, l'application retombe sur le mode sans IA et le dit. La qualité des textes dépend du modèle : relisez toujours.

## Autorisations
- **Réseau** : aucune requête, sauf vers `api.anthropic.com` si (et seulement si) une clé est configurée. Aucune analyse, télémétrie, publicité ni compte tiers.
- **Fichiers** : lecture/écriture limitées à `DATA_DIR` (base SQLite) et `PUBLISH_DIR` (sites publiés).
- **Réseau local** : le serveur n'écoute que sur `127.0.0.1` ; les requêtes d'écriture d'une autre origine sont refusées.
- **Secrets** : uniquement dans `.env` (ignoré par git). La clé n'est jamais renvoyée au navigateur ni journalisée ; le journal n'écrit jamais le contenu des sites.

## Architecture
```
src/lib/        types, validation, SQLite (store), rendu pur (render), IA (ai), générateur sans IA, ZIP, publication
src/app/api/    routes : projets, import, export, zip, publication, réécriture IA, exemples, santé
src/app/        pages : tableau de bord, éditeur   |   src/components/ : éditeur, formulaires de sections
tests/          modèle de données, SQLite, générateur + IA simulée, rendu, boucle complète
```
Le **rendu** est une fonction pure sans module Node : le même code produit l'aperçu (dans un `iframe` sandboxé, sans script) et les fichiers publiés.

## Où sont mes données ? Sauvegarde
| Quoi | Où |
|---|---|
| Sites (JSON dans SQLite) | `data/hexsite.db` (+ `-wal`, `-shm`) |
| Sites publiés | `exports/<site>/` |
Sauvegarde : **Exporter (JSON)** par site depuis l'interface, ou copier le dossier `data/` application arrêtée. Restauration : **Importer un export JSON**.

## Exemples
« Charger un exemple fictif » crée un site étiqueté **[EXEMPLE]**, supprimable en un clic (« Supprimer les exemples »). Rien n'est créé automatiquement.

## Limitations
- Édition **par sections structurées** uniquement (pas d'éditeur visuel généraliste), **six types de sections**, aucune grande bibliothèque de modèles ou de composants : choix volontaires.
- Pas de gestion d'e-mail (réputation d'expéditeur, délivrabilité, suppressions) : hors périmètre.
- Pas d'hébergement ni de domaine : vous copiez les fichiers où vous voulez.
- Pas de comptes : une seule personne, en local. Ne l'exposez pas sur Internet sans ajouter une authentification.
- Qualité du mode IA non mesurée ; l'appel à l'API Anthropic est testé avec des réponses simulées, pas avec un vrai compte.
- Accessibilité : étiquettes, focus visible, navigation clavier, contrastes soignés (non audités avec un outil).
- **État de vérification** : les 23 tests passent (modèle, SQLite, générateur, rendu, boucle complète via les vraies routes). L'interface React et `next build` n'ont pas pu être exécutés dans l'environnement où le projet a été écrit (pas de réseau pour installer Next) : la CI GitHub fournie les exécute.
