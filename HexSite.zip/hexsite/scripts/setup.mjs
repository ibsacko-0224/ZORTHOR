#!/usr/bin/env node
// Installation en une commande : node scripts/setup.mjs   (ou : npm run setup)
import { copyFileSync, existsSync, mkdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';

const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 13)) {
  console.error(`✗ Node 22.13 ou plus requis (détecté : ${process.versions.node}). SQLite est fourni par Node.`);
  process.exit(1);
}
if (!existsSync('.env')) {
  copyFileSync('.env.example', '.env');
  console.log('→ .env créé à partir de .env.example (aucune clé : mode sans IA).');
}
mkdirSync('data', { recursive: true });
const win = process.platform === 'win32';
if (!existsSync('node_modules')) {
  console.log('→ Installation des dépendances…');
  const r = spawnSync(win ? 'npm.cmd' : 'npm', ['install', '--no-audit', '--no-fund'], { stdio: 'inherit', shell: win });
  if (r.status !== 0) process.exit(r.status ?? 1);
}
console.log('✓ Prêt. Lancez : npm run dev   puis ouvrez http://127.0.0.1:3000');
